package com.aditya.emailservice.service;

import com.aditya.emailservice.model.Mail;

public interface MailService 
{
	public void sendEmail(Mail mail);
}
